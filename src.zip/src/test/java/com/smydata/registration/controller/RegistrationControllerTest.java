package com.smydata.registration.controller;

import static org.junit.Assert.assertNotNull;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.smydata.registration.RegistrationApplication;
import com.smydata.registration.model.Registration;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RegistrationApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RegistrationControllerTest {

	@Autowired
	private TestRestTemplate testRestTemplate;
	
	@LocalServerPort
	private int port;
	
	public static final String serviceUri = "http://localhost:";
	private String uri = "";
	/*@Before
	public void setUp() throws Exception {
	}
	
	@After
	public void tearDown() {
		uri = "";
	}*/
	
	/*@Test
	public void testSaveUser(){
		Registration registration = getRegistrationMetadata();
		uri = serviceUri + port + "/saveUser/registration";
		System.out.println("uri: "+uri);
		try{
			HttpEntity<Registration> regEntity = new HttpEntity<Registration>(registration);
			ResponseEntity<?> response = testRestTemplate.exchange(uri, HttpMethod.POST, regEntity,String.class);
			assertNotNull(response);
			assertEquals(HttpStatus.OK,response.getStatusCode());
//			assertEquals("success",response.getBody());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}*/
	
	private Registration getRegistrationMetadata(){
		Registration registration = new Registration();
		registration.setBusinessAddress("Hyderabad");
		registration.setCategory("2");
		registration.setCity("Hyderabad");
		registration.setCompanyName("SMD");
		registration.setCountry("India");
		registration.setEmail("smyadata2@gmail.com");
		registration.setMobile("9440717764");
		registration.setOwnerName("SMD");
		registration.setPassword("smd123");
		registration.setPinCode("500008");
		registration.setReg("business1");
		registration.setRegProof("2222");
		registration.setState("TS");
		registration.setWebsite("smd.com");
		return registration;
	}
}
