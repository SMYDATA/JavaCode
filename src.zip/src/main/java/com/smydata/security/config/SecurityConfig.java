package com.smydata.security.config;

import org.springframework.context.annotation.Configuration;

@Configuration
//@EnableGlobalMethodSecurity(securedEnabled = true)
public class SecurityConfig /*extends AuthenticationConfiguration */{

	
}
